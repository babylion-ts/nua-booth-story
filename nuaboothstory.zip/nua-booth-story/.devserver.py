#!/usr/bin/env python3
# 개발용 정적 서버 — 캐시 비활성화(no-store)로 편집이 항상 즉시 반영되게 한다.
import http.server
import socketserver
import os

PORT = 4173
DIRECTORY = os.path.dirname(os.path.abspath(__file__))


class NoCacheHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("", PORT), NoCacheHandler) as httpd:
    print(f"NUA dev server (no-cache) on http://localhost:{PORT}  dir={DIRECTORY}")
    httpd.serve_forever()
